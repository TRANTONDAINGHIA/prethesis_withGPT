import './index.css';
import React, { useState } from 'react';
import axios from 'axios';
import { MainContainer, ChatContainer, MessageList, Message, MessageInput, TypingIndicator } from '@chatscope/chat-ui-kit-react';
import banner from './banner.jpg';
import logo from './logo.jpg';
import comma from './comma.jpg';
import ad from './ad.jpg';

const API_KEY = "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";

function App() {
  const [inputValue, setInputValue] = useState('');
  const [tp, setTp] = useState({low: [], m: [], high: [], no: []});

  const [messages, setMessages] = useState([
    { message: "Hello, I'm ChatGPT! Ask me anything!", sentTime: "just now", sender: "ChatGPT" },
  ]);
  const [isTyping, setIsTyping] = useState(false);

  const handleSendRequest = async (message) => {
    const newMessage = { message, direction: 'outgoing', sender: "user" };
    setMessages((prevMessages) => [...prevMessages, newMessage]);
    setIsTyping(true);

    try {
      const response = await processMessageToChatGPT([...messages, newMessage]);
      const content = response.choices[0]?.message?.content;
      if (content) {
        const chatGPTResponse = { message: content, sender: "ChatGPT" };
        setMessages((prevMessages) => [...prevMessages, chatGPTResponse]);
      }
    } catch (error) {
      console.error("Error processing message:", error);
    } finally {
      setIsTyping(false);
    }
  };

  async function processMessageToChatGPT(chatMessages) {
    const apiMessages = chatMessages.map((messageObject) => {
      const role = messageObject.sender === "ChatGPT" ? "assistant" : "user";
      return { role, content: messageObject.message };
    });

    const apiRequestBody = {
      "model": "gpt-3.5-turbo",
      "messages": [
        { role: "system", content: "I'm a Student using ChatGPT for learning" },
        ...apiMessages,
      ],
    };

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(apiRequestBody),
    });

    return response.json();
  }

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };
  const handleButtonClick = async () => {
    let tmp = inputValue.split(",");
    let res = await postData("https://callmeduy.com/_api/chemicals/search?", {names: tmp});
    setTp({low: [], m: [], high: [], no: []});
    res.forEach(element => {
      if (element.rating === 1) {
        setTp((prevState) => ({
          ...prevState,
          low: [...prevState.low, element.names[0].name],
        }));
      } else if (element.rating === 2) {
        setTp((prevState) => ({
          ...prevState,
          m: [...prevState.m, element.names[0].name],
        }));
      } else if (element.rating === 3) {
        setTp((prevState) => ({
          ...prevState,
          high: [...prevState.high, element.names[0].name],
        }));
      } else {
        setTp((prevState) => ({
          ...prevState,
          no: [...prevState.no, element.names[0].name],
        }));
      }
    });
  };

  async function postData(url, data) {
    try {
      const response = await axios.post(url, data);
      return response.data;
    } catch (error) {
      console.error('Error:', error.message);
      throw error;
    }
  }

  return (
    <div className="App">
      <header>
        <div className='logo'>
          <img className='logo' src={logo} alt='logo' />
        </div>
        <nav>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#about">Ingredient</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </nav>
      </header>
      <div>
        <span>
          <img src={banner} alt="Description of the image" />
      </span>
      <div className='content'>
      <div className='ad-1'>
        <img src={ad} alt='ad' />
        <p>Comedogenic ingredients in skincare are substances that can lead to blocked pores, contributing to the development of acne. It's important for consumers to read product labels and understand their skin's needs to choose appropriate skincare products.</p>
      </div>
        <div className='analyze'>
          <div className='a-input'>
            <h2>User manual</h2>
            <p>Enter the name of each substance you want to look up.</p>
            <p>To separate substances, you can enter the characters comma.<img id='comma' src={comma} alt='comma' /></p>
            <p>You can also copy and paste a list of substances on a website and the app will try to predict the substances in that list. You can still correct it if the app predicts wrongly.</p>
            <div className='input-c'>
              <textarea type="text" value={inputValue} onChange={handleInputChange} />
              <button onClick={handleButtonClick}>✈️</button>
            </div>
          </div>
          <div className='result'>
            <p>Low risk: {tp.low.map((i) => (i + "\t"))}</p>
            <p>Normal state: {tp.m.map((i) => (i + "\t"))}</p>
            <p>High risk: {tp.high.map((i) => (i + "\t"))}</p>
            <p>No data available: {tp.no.map((i) => (i + "\t"))}</p>
          </div>
        </div>
        <div className='chat-box'>
          <MainContainer>
            <ChatContainer>
              <MessageList scrollBehavior="smooth" typingIndicator={isTyping ? <TypingIndicator content="ChatGPT is typing" /> : null}>
                {messages.map((message, i) => {
                  return <div className='message'><Message key={i} model={message} /></div>
                })}
              </MessageList>
              <MessageInput placeholder="Send a Message" onSend={handleSendRequest} />
            </ChatContainer>
          </MainContainer>
        </div>
      </div>
      </div>
    </div>
  );
}

export default App;
